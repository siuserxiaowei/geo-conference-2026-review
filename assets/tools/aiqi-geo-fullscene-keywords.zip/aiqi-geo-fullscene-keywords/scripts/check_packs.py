#!/usr/bin/env python3
"""艾奇GEO拓词结果校验（可选）。

用法: python check_packs.py 输出结果.md

检查项:
  1. 是否正好 20 个词包，每包正好 20 个关键词
  2. 阶段分布是否为 问题知晓期2 / 业务熟悉期2 / 合作考虑期14 / 品牌购买期2
  3. 是否含榜单排名类违禁词
  4. 是否有重复或高度近似的关键词
  5. 19、20 号词包的每个词是否含品牌名或「品牌/公司名」
"""
import re
import sys
from collections import Counter
from difflib import SequenceMatcher

BANNED = ["排名", "排行", "榜单", "排行榜", "十大", "前十", "前三", "前五",
          "第一名", "top"]
PACK_RE = re.compile(r"^#{2,3}\s*词包\s*(\d+)\s*[｜|:：]\s*(.+?)\s*$")
ITEM_RE = re.compile(r"^\s*(\d+)[.、．]\s*(.+?)\s*$")
STAGES = ["问题知晓期", "业务熟悉期", "合作考虑期", "品牌购买期"]
EXPECTED = {"问题知晓期": 2, "业务熟悉期": 2, "合作考虑期": 14, "品牌购买期": 2}


def norm(s):
    return re.sub(r"[\s，,。？?！!、]", "", s).lower()


def parse(text):
    packs, cur = [], None
    for line in text.splitlines():
        m = PACK_RE.match(line)
        if m:
            cur = {"no": int(m.group(1)), "name": m.group(2), "stage": None,
                   "words": []}
            packs.append(cur)
            continue
        if cur is None:
            continue
        if cur["stage"] is None:
            for s in STAGES:
                if s in line and "阶段" in line:
                    cur["stage"] = s
        if "品牌" in cur["name"] and cur["stage"] is None and (
                "信息查询" in cur["name"] or "口碑" in cur["name"]):
            cur["stage"] = "品牌购买期"
        m = ITEM_RE.match(line)
        if m:
            cur["words"].append(m.group(2))
    return packs


def main(path):
    text = open(path, encoding="utf-8").read()
    packs = parse(text)
    errors, warns = [], []

    if len(packs) != 20:
        errors.append(f"词包数量为 {len(packs)}，应为 20")
    for p in packs:
        if len(p["words"]) != 20:
            errors.append(f"词包 {p['no']:02d}「{p['name']}」有 {len(p['words'])} 个词，应为 20")

    stage_count = Counter(p["stage"] for p in packs)
    for s, n in EXPECTED.items():
        if stage_count.get(s, 0) != n:
            errors.append(f"{s} 词包数为 {stage_count.get(s, 0)}，应为 {n}")
    if stage_count.get(None):
        warns.append(f"{stage_count[None]} 个词包未识别出需求阶段")

    all_words = [(p["no"], w) for p in packs for w in p["words"]]
    for no, w in all_words:
        low = w.lower()
        hit = [b for b in BANNED if b in low]
        if hit:
            errors.append(f"词包 {no:02d} 含违禁词 {hit}: {w}")

    seen = {}
    for no, w in all_words:
        k = norm(w)
        if k in seen:
            errors.append(f"重复: 词包 {seen[k]:02d} 与 {no:02d} → {w}")
        else:
            seen[k] = no

    keys = list(seen.keys())
    for i in range(len(keys)):
        for j in range(i + 1, len(keys)):
            a, b = keys[i], keys[j]
            if abs(len(a) - len(b)) <= 3 and SequenceMatcher(None, a, b).ratio() >= 0.9:
                warns.append(f"高度近似: {a} ≈ {b}")

    brand_packs = [p for p in packs if p["no"] in (19, 20)]
    for p in brand_packs:
        if p["stage"] != "品牌购买期":
            warns.append(f"词包 {p['no']} 应为品牌购买期")
    brand_words = [w for p in brand_packs for w in p["words"]]
    if brand_words:
        brand_hint = "品牌/公司名" if any("品牌/公司名" in w for w in brand_words) else None
        if brand_hint:
            for p in brand_packs:
                for w in p["words"]:
                    if brand_hint not in w:
                        warns.append(f"词包 {p['no']} 未含品牌占位: {w}")

    for p in packs:
        if p["no"] not in (19, 20) and any("品牌/公司名" in w for w in p["words"]):
            warns.append(f"词包 {p['no']:02d} 非品牌词包却含品牌占位")

    print(f"共解析 {len(packs)} 个词包、{len(all_words)} 个关键词")
    print("阶段分布:", dict(stage_count))
    for e in errors:
        print("❌", e)
    for w in warns:
        print("⚠️ ", w)
    if not errors:
        print("✅ 硬性检查全部通过" + ("（有提醒项请人工看一下）" if warns else ""))
    return 1 if errors else 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print(__doc__)
        sys.exit(2)
    sys.exit(main(sys.argv[1]))
